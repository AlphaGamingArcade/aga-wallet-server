const httpStatus = require("http-status");
const { DEFAULT_QUERY_LIMIT, DEFAULT_QUERY_OFFSET } = require("../utils/constants");

const Asset = require("../models/asset.model");

/**
 * Load wallet and append to req.locals.
 * @public
 */
exports.load = async (req, res, next, assetId) => {
    try {
      const asset = await  Asset.getById(assetId);
      req.locals = { asset: { ...asset } };
      return next();
    } catch (error) {
      return next(error);
    }
};

/**
 * Get asset
 * @public
 */
exports.get = (req, res) => res.json(req.locals.asset);

/**
 * Get All Assets
 */
exports.getAssets = async (req, res, next) => {
  try {
    const assets = await Asset.getAssets({
      limit: req.query.limit || DEFAULT_QUERY_LIMIT,
      offset: req.query.offset || DEFAULT_QUERY_OFFSET
    });
    res.status(httpStatus.OK);
    return res.json({ ...assets });
  } catch (error) {
    return next(error)
  }
}